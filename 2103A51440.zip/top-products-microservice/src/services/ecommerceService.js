const axios = require('axios');
const { getAuthToken } = require('../config/auth');
require('dotenv').config();

const companies = ['company1', 'company2', 'company3', 'company4', 'company5'];

const fetchProducts = async (category_name) => {
  const token = await getAuthToken();
  const products = [];

  for (let company of companies) {
    try {
      const response = await axios.get(`http://20.244.56.144/test/${company}/categories/${category_name}/products`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      products.push(...response.data);
    } catch (error) {
      console.error(`Failed to fetch products from ${company}:`, error.message);
    }
  }

  return products;
};

const fetchProductDetails = async (category_name, product_id) => {
  const token = await getAuthToken();
  for (let company of companies) {
    try {
      const response = await axios.get(`http://20.244.56.144/test/${company}/categories/${category_name}/products/${product_id}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (response.data) {
        return response.data;
      }
    } catch (error) {
      console.error(`Failed to fetch product details from ${company}:`, error.message);
    }
  }
  return null;
};

module.exports = { fetchProducts, fetchProductDetails };
