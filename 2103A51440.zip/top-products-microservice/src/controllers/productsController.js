const { fetchProducts, fetchProductDetails } = require('../services/ecommerceService');
const { v4: uuidv4 } = require('uuid');

const getProducts = async (req, res, next) => {
  try {
    const { category_name } = req.params;
    const { N = 10, page = 1, sort_by, order } = req.query;

    const products = await fetchProducts(category_name);

    let sortedProducts = products.sort((a, b) => {
      if (sort_by) {
        if (order === 'asc') return a[sort_by] - b[sort_by];
        return b[sort_by] - a[sort_by];
      }
      return 0;
    });

    const paginatedProducts = sortedProducts.slice((page - 1) * 10, page * 10);

    const result = paginatedProducts.map(product => ({
      ...product,
      id: uuidv4(),
    }));

    res.json(result);
  } catch (err) {
    next(err);
  }
};

const getProductById = async (req, res, next) => {
  try {
    const { category_name, product_id } = req.params;

    const product = await fetchProductDetails(category_name, product_id);

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json(product);
  } catch (err) {
    next(err);
  }
};

module.exports = { getProducts, getProductById };
