const axios = require('axios');
require('dotenv').config();

const registerCompany = async () => {
  const data = {
    companyName: 'goMart',
    ownerName: 'Praveen',
    rollNo: '2103A51440',
    ownerEmail: 'newemail@example.com', // Use a different email address
    accessCode: 'CDGhzZ'
  };

  try {
    const response = await axios.post('http://20.244.56.144/test/register', data);
    console.log('Registration successful:', response.data);
  } catch (error) {
    console.error('Registration failed:', error.response ? error.response.data : error.message);
  }
};

registerCompany();
