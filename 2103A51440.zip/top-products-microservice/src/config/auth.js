const axios = require('axios');
require('dotenv').config();

const getAuthToken = async () => {
  const data = {
    companyName: process.env.COMPANY_NAME,
    clientId: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    ownerName: 'Praveen',
    ownerEmail: process.env.OWNER_EMAIL,
    rollNo: process.env.ROLL_NO
  };

  try {
    const response = await axios.post('http://20.244.56.144/test/auth', data);
    console.log('Authorization successful, token:', response.data.access_token);
    return response.data.access_token;
  } catch (error) {
    console.error('Auth failed:', error.response ? error.response.data : error.message);
    throw error;
  }
};

getAuthToken();
