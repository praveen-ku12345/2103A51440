const express = require('express');
const { getProducts, getProductById } = require('../controllers/productsController');

const router = express.Router();

router.get('/:category_name/products', getProducts);
router.get('/:category_name/products/:product_id', getProductById);

module.exports = router;
